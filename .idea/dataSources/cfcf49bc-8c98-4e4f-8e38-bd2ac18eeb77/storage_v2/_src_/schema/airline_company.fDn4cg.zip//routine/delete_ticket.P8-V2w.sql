create
    definer = root@localhost procedure delete_ticket(IN id int)
Begin
delete from ticket where TicketID= id;
delete from ticket_purchase where TicketID=id;
end;

