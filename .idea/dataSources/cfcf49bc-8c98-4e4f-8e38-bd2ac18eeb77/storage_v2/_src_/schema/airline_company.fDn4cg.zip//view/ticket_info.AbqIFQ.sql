create definer = root@localhost view ticket_info as
select `z`.`TicketID`            AS `TicketID`,
       `z`.`Class`               AS `Class`,
       `z`.`Seat`                AS `Seat`,
       `r`.`Departure_moment`    AS `Departure_moment`,
       `r`.`Departure_AirportID` AS `Departure_AirportID`,
       `r`.`Arrival_AirportID`   AS `Arrival_AirportID`,
       `z`.`Price`               AS `Price`,
       `z`.`FlightID`            AS `FlightID`
from (`airline_company`.`ticket` `z`
         join `airline_company`.`flight_table` `r`)
where (`z`.`FlightID` = `r`.`FlightID`);

