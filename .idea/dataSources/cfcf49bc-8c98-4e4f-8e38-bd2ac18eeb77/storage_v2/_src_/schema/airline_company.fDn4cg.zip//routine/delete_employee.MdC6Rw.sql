create
    definer = root@localhost procedure delete_employee(IN id bigint(11))
Begin
delete from employee where EmpID = id;
delete from flight_has_employee where EmployeeID = id;
delete from airport_has_employee where Employee_EmpID = id;
end;

