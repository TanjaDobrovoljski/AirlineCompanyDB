create
    definer = root@localhost procedure delete_flight(IN id int)
Begin
delete from flight where FlightID= id;
delete from flight_has_employee where flight = id;
delete from flight_has_passenger where FlightID = id;
delete from reservation where FlightID=id;
delete from ticket where FlightID=id;
delete from ticket_purchase where FlightID=id;
end;

