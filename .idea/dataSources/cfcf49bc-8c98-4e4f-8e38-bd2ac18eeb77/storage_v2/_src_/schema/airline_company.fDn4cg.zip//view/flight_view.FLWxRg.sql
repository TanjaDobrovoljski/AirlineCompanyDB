create definer = root@localhost view flight_view as
select `z`.`FlightID`            AS `FlightID`,
       `z`.`Duration`            AS `Duration`,
       `z`.`Date`                AS `Date`,
       `z`.`Departure_AirportID` AS `Departure_AirportID`,
       `z`.`Arrival_AirportID`   AS `Arrival_AirportID`,
       `z`.`Departure_moment`    AS `Departure_moment`,
       `z`.`Arrival_moment`      AS `Arrival_moment`,
       `z`.`AirplaneID`          AS `AirplaneID`,
       `z`.`Status`              AS `Status`,
       `r`.`EmployeeID`          AS `EmployeeID`
from (`airline_company`.`flight` `z`
         join `airline_company`.`flight_has_employee` `r` on ((`z`.`FlightID` = `r`.`FlightID`)))
where (`z`.`FlightID` = `r`.`FlightID`);

