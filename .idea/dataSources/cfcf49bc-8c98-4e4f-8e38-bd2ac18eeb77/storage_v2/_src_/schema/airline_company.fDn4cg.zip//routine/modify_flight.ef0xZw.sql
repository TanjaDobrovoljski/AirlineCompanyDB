create
    definer = root@localhost procedure modify_flight(IN id INT(10), IN Date DATE(10), IN Duration INT(10),
                                                     IN Departure_moment DATETIME(19), IN AirplaneID INT(10))
begin
update flight set Duration = Duration where FlightID=id;
update flight set Date=Date  where FlightID = id;
update flight set Departure_moment = Departure_moment where FlightID = id;
update flight set AirplaneID=AirplaneID  where FlightID = id;

end;

