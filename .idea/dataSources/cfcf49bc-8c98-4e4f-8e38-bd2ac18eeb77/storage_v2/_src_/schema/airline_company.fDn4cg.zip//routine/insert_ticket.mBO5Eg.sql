create procedure insert_ticket(IN TicketID INT(10), IN Price DECIMAL(10, 3), IN Class VARCHAR(45), IN Seat VARCHAR(45),
                               IN FlightID INT(10), IN PassengerPID INT(10), IN Name VARCHAR(45),
                               IN Surname VARCHAR(45), IN Date_of_birth DATE(10), IN Address VARCHAR(45),
                               IN Passport_number VARCHAR(20), IN State_Zip INT(10))
begin
insert into ticket values(TicketID,Price,Class,Seat,FlightID,PassengerPID);
insert into passenger values(PassengerPID,Name,Surname,Date_of_birth,Address,Passport_number,State_Zip);
end;

