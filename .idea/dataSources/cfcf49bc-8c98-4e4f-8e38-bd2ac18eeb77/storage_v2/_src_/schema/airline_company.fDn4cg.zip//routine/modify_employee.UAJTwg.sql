create procedure modify_employee(IN EmpID BIGINT(19), IN Name VARCHAR(30), IN Surname VARCHAR(40),
                                 IN Address VARCHAR(45), IN Birth_date DATE(10), IN Birth_place VARCHAR(30),
                                 IN Email VARCHAR(32), IN Tel VARCHAR(30), IN Bank_account_number VARCHAR(20),
                                 IN Salary DECIMAL(10, 3), IN BranchID INT(10))
begin
update employee set Name = Name where EmpID=EmpID;
update employee set Surname=Surname  where EmpID=EmpID;
update employee set Address = Address where EmpID=EmpID;
update employee set Birth_date=Birth_date  where EmpID=EmpID;
update employee set Birth_place = Birth_place where EmpID=EmpID;
update employee set Email=Email  where EmpID=EmpID;
update employee set Tel = Tel where EmpID=EmpID;
update employee set Bank_account_number=Bank_account_number  where EmpID=EmpID;
update employee set Salary = Salary where EmpID=EmpID;
update employee set BranchID=BranchID  where EmpID=EmpID;
update employee set Departure_moment = Departure_moment where EmpID=EmpID;
update employee set AirplaneID=AirplaneID  where EmpID=EmpID;
end;

