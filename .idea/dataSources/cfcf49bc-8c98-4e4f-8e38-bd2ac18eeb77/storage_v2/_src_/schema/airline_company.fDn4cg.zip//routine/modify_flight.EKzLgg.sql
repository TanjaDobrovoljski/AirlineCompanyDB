create
    definer = root@localhost procedure modify_flight(IN id int, IN Date date, IN Duration int(5),
                                                     IN Departure_moment datetime, IN AirplaneID int)
begin
update flight set Duration = Duration where FlightID=id;
update flight set Date=Date  where FlightID = id;
update flight set Departure_moment = Departure_moment where FlightID = id;
update flight set AirplaneID=AirplaneID  where FlightID = id;

end;

