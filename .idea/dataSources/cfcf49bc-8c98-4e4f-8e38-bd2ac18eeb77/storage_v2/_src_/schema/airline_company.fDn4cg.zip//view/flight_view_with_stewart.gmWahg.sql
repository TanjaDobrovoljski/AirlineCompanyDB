create definer = root@localhost view flight_view_with_stewart as
select `z`.`FlightID`            AS `FlightID`,
       `z`.`Duration`            AS `Duration`,
       `z`.`Date`                AS `Date`,
       `z`.`Departure_AirportID` AS `Departure_AirportID`,
       `z`.`Arrival_AirportID`   AS `Arrival_AirportID`,
       `z`.`Departure_moment`    AS `Departure_moment`,
       `z`.`Arrival_moment`      AS `Arrival_moment`,
       `z`.`AirplaneID`          AS `AirplaneID`,
       `z`.`Status`              AS `Status`,
       `r`.`Name`                AS `Name`,
       `r`.`Surname`             AS `Surname`
from (`airline_company`.`flight_view` `z`
         join `airline_company`.`employee` `r`)
where ((`z`.`EmployeeID` = `r`.`EmpID`) and (`r`.`Duty` = 2));

