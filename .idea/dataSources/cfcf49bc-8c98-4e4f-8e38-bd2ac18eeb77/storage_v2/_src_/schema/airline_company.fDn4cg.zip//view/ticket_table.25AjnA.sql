create definer = root@localhost view ticket_table as
select `z`.`TicketID`                      AS `TicketID`,
       `r`.`Name`                          AS `Name`,
       `r`.`Surname`                       AS `Surname`,
       `r`.`PassengerPID`                  AS `PassengerPID`,
       `r`.`Passport_number`               AS `Passport_number`,
       `z`.`Class`                         AS `Class`,
       `z`.`Seat`                          AS `Seat`,
       `z`.`Departure_moment`              AS `Departure_moment`,
       `z`.`Departure_AirportID`           AS `Departure_AirportID`,
       `z`.`Arrival_AirportID`             AS `Arrival_AirportID`,
       `r`.`Passenger_bank_account_number` AS `Passenger_bank_account_number`,
       `z`.`Price`                         AS `Price`
from (`airline_company`.`ticket_info` `z`
         join `airline_company`.`table1` `r`)
where (`z`.`FlightID` = `r`.`FlightID`);

