create procedure insert_flight(IN FlightID INT(10), IN Duration INT(10), IN Date DATE(10),
                               IN Departure_moment DATETIME(19), IN Arrival_moment DATETIME(19),
                               IN Departure_gate VARCHAR(45), IN Arrival_gate VARCHAR(45), IN AirplaneID INT(10),
                               IN Departure_AirportID INT(10), IN Arrival_AirportID INT(10), IN Status TINYINT(3))
begin
insert into flight values(FlightID,Duration,Date,Departure_moment,Arrival_moment,Departure_gate,Arrival_gate,AirplaneID,Departure_AirportID,Arrival_AirportID,Status);

end;

