create definer = root@localhost view table1 as
select `z`.`Name`                          AS `Name`,
       `z`.`Surname`                       AS `Surname`,
       `z`.`PassengerPID`                  AS `PassengerPID`,
       `z`.`Passport_number`               AS `Passport_number`,
       `r`.`FlightID`                      AS `FlightID`,
       `z`.`Passenger_bank_account_number` AS `Passenger_bank_account_number`
from (`airline_company`.`pass_bank_account` `z`
         join `airline_company`.`flight_has_passenger` `r`)
where (`z`.`PassengerPID` = `r`.`PassengerID`);

