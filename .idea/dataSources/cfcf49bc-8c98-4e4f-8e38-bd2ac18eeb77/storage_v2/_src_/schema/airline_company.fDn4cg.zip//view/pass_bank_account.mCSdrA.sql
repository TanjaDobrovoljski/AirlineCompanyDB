create definer = root@localhost view pass_bank_account as
select `z`.`Name`                          AS `Name`,
       `z`.`Surname`                       AS `Surname`,
       `z`.`PassengerPID`                  AS `PassengerPID`,
       `z`.`Passport_number`               AS `Passport_number`,
       `r`.`Passenger_bank_account_number` AS `Passenger_bank_account_number`
from (`airline_company`.`passenger` `z`
         join `airline_company`.`passenger_bank_account` `r`)
where (`z`.`PassengerPID` = `r`.`PassengerPID`);

