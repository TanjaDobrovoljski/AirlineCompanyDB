create procedure insert_employee(IN EmpID BIGINT(19), IN Name VARCHAR(30), IN Surname VARCHAR(40),
                                 IN Address VARCHAR(45), IN Birth_date DATE(10), IN Birth_place VARCHAR(30),
                                 IN Email VARCHAR(32), IN Tel VARCHAR(30), IN Duty TINYINT(3),
                                 IN Bank_account_number VARCHAR(20), IN Salary DECIMAL(10, 3), IN BranchID INT(10))
begin
insert into employee values (EmpID,Name,Surname,Address,Birth_date,Birth_place,Email,Tel,Duty,Bank_account_number,Salary,BranchID);

end;

