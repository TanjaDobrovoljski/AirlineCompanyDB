create definer = root@localhost view flight_table as
select `z`.`FlightID`            AS `FlightID`,
       `z`.`Duration`            AS `Duration`,
       `z`.`Date`                AS `Date`,
       `z`.`Departure_AirportID` AS `Departure_AirportID`,
       `z`.`Arrival_AirportID`   AS `Arrival_AirportID`,
       `z`.`Departure_moment`    AS `Departure_moment`,
       `z`.`Arrival_moment`      AS `Arrival_moment`,
       `z`.`AirplaneID`          AS `AirplaneID`,
       `z`.`Status`              AS `Status`,
       `z`.`Name1`               AS `Name1`,
       `z`.`Surname1`            AS `Surname1`,
       `r`.`Name`                AS `Name`,
       `r`.`Surname`             AS `Surname`
from (`airline_company`.`flight_view_with_employee` `z`
         join `airline_company`.`flight_view_with_stewart` `r`
              on (((`z`.`FlightID` = `r`.`FlightID`) and (`z`.`Duration` = `r`.`Duration`) and
                   (`z`.`Date` = `r`.`Date`) and (`z`.`Departure_AirportID` = `r`.`Departure_AirportID`) and
                   (`z`.`Arrival_AirportID` = `r`.`Arrival_AirportID`) and
                   (`z`.`Departure_moment` = `r`.`Departure_moment`) and
                   (`z`.`Arrival_moment` = `r`.`Arrival_moment`) and (`z`.`AirplaneID` = `r`.`AirplaneID`) and
                   (`z`.`Status` = `r`.`Status`))))
where (`z`.`FlightID` = `r`.`FlightID`);

