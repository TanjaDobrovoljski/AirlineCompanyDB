create definer = root@localhost view passenger_info as
select `z`.`Name`            AS `Name`,
       `z`.`Surname`         AS `Surname`,
       `z`.`PassengerPID`    AS `PassengerPID`,
       `z`.`Passport_number` AS `Passport_number`
from `airline_company`.`passenger` `z`;

